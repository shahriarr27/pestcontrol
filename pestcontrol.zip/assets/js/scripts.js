$( "#selectDate" ).datepicker({
  dateFormat: "dd/mm/yy",
  duration: "fast",
  minDate: 0, 
  maxDate: "+1M +10D"
});
